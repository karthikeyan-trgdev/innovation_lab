<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Innovation Lab | CMIS, Coimbatore</title>
    <link rel="icon" type="image/x-icon" href="./assets/images/favicon.svg" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="assets/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"/>
  </head>
  <body>
    <header class="main-header">
      <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
          <a class="navbar-brand logo" href="#">
            <img src="assets/images/cmis_logo.png" alt="CMIS Logo" />
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="top-header">
              <div class="top-header-contents">
                <div class="social-media">
                  <i class="fa-brands fa-facebook-f"></i>
                  <i class="fa-brands fa-linkedin-in"></i>
                  <i class="fa-brands fa-instagram"></i>
                  <i class="fa-brands fa-youtube"></i>
                </div>
                <div class="top-menus">
                  <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="#"
                        >Gallery</a
                      >
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        aria-expanded="false"
                      >
                        Accolades
                      </a>
                      <ul class="dropdown-menu">
                        <li>
                          <a class="dropdown-item" href="#">News and Events</a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">CMIS in news</a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="#"
                        >Resources</a
                      >
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Careers</a>
                    </li>
                  </ul>
                </div>
                <div class="top-btns">
                  <button class="theme-btn animation-btn">CMIS Portal</button>
                  <button class="theme-btn yellow--btn animation-btn">
                    Download Brochure
                  </button>
                </div>
              </div>
            </div>
            <div class="primary-header">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#"
                    >Home</a
                  >
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    aria-expanded="false"
                  >
                    About Us
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="dropdown-item" href="#">Vision & Mission</a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">Core Value of CMIS</a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">Founder's desk</a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">Principal's Message</a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#"
                        >School Management Committee</a
                      >
                    </li>
                    <li>
                      <a class="dropdown-item" href="#"
                        >Parents Teachers Association</a
                      >
                    </li>
                  </ul>
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    aria-expanded="false"
                  >
                    Academics
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="dropdown-item" href="#">Foundation Stage</a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">Preparatory Stage</a>
                    </li>
                    <li><a class="dropdown-item" href="#">Middle Stage</a></li>
                    <li>
                      <a class="dropdown-item" href="#">Secondary Stage</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Life at CMIS</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Admissions</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Facilities</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="#">Innovation Lab</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Value Journal</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Contact</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </header>