<?php include("header.php") ?>

<section class="breadcrumb">
    <div class="container">
        <div class="row">
            <div class="breadcrumb-content">
                <h6><a href="">Home</a></h6>
                <h6>>></h6>
                <h6><a href="">Innovation Lab</a></h6>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">
            <div class="theme-title">
                <h1>Innovation <span>Labs</span></h1>
                <p>
                    Explore our innovative learning programs designed for different
                    age groups
                </p>
            </div>

            <div class="segment-category">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#home"><span><img
                                    src="assets/images/icons/pre-primary-icon.svg"
                                    alt="" /></span>Pre-primary group</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#menu1"><span><img
                                    src="assets/images/icons/primary-icon.svg"
                                    alt="" /></span>Primary Segment</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#menu2"><span><img
                                    src="assets/images/icons/highschool-icon.svg"
                                    alt="" /></span>Highschool</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content individual-segment">
                    <div class="row">
                        <div class="card-navigation">
                            <div class="title">
                                <h1><span>Fun Facts</span> Time</h1>
                            </div>
                            <div class="back">
                                <h6><a href="index.php"><i class="fa-solid fa-chevron-left"></i> Back</a></h6>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane container active" id="home">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <a type="button" data-bs-toggle="modal" data-bs-target="#myModal">
                                        <div class="image">
                                            <img
                                                src="assets/images/fun-facts/universe/universe-thumb.jpg"
                                                alt="" />
                                        </div>
                                        <div class="content">
                                            <h1>Fun Facts</h1>
                                            <p>“Universe of Facts: Science & Tech” is a unique collection of fascinating and lesser-known facts from Space, Robotics, Aerospace, and Computer Science, presented in an entertaining and memorable way. Each month, ten new facts will be added, helping visitors expand their knowledge of science and technology in a fun and engaging manner.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane container fade" id="menu1">...</div>
                    <div class="tab-pane container fade" id="menu2">...</div>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- The Modal -->
<div class="modal segment-popup" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="quiz-container">
                            <div class="quiz-header-bar">
                                <div class="quiz-question-box">
                                    <span class="quiz-question-text">
                                        Which innovation allows doctors to look inside the human body without surgery?
                                    </span>
                                </div>
                                <div class="icon-atom">
                                    <svg viewBox="0 0 100 100">
                                        <circle cx="50" cy="50" r="8" fill="#4B8BF5" />
                                        <path d="M50,50 L50,0 M50,50 L100,50 M50,50 L75,93.3" fill="none" stroke="#4B8BF5" stroke-width="2" />
                                        <ellipse cx="50" cy="50" rx="45" ry="15" transform="rotate(0, 50, 50)" fill="none" stroke="#4B8BF5" stroke-width="1.5" />
                                        <ellipse cx="50" cy="50" rx="45" ry="15" transform="rotate(60, 50, 50)" fill="none" stroke="#4B8BF5" stroke-width="1.5" />
                                        <ellipse cx="50" cy="50" rx="45" ry="15" transform="rotate(120, 50, 50)" fill="none" stroke="#4B8BF5" stroke-width="1.5" />
                                    </svg>
                                </div>
                            </div>

                            <div class="quiz-main-content">
                                <div class="quiz-options-section">
                                    <div class="icon-dna">
                                    </div>
                                    <div class="quiz-options">
                                        <button class="answer-button correct-answer">X-ray imaging</button>
                                        <button class="answer-button">Electric Motor</button>
                                        <button class="answer-button">Steam Engine</button>
                                        <button class="answer-button">Printing Press</button>
                                    </div>
                                    <div class="icon-rocket">
                                    </div>
                                </div>

                                <div class="quiz-illustration-section">
                                    <div class="illustration-placeholder">
                                        <p>Illustration of Doctor and Patient goes here</p>
                                    </div>
                                    <div class="bottom-circuit-decor">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
</div>



<?php include("footer.php") ?>

<script>
    $(document).ready(function() {
        // Cybermax modal
        $('#myModal').on('shown.bs.modal', function() {
            var $carousel = $(this).find('.owl-carousel');

            if (!$carousel.hasClass('owl-loaded')) {
                $carousel.owlCarousel({
                    loop: false,
                    margin: 10,
                    nav: true,
                    dots: false,
                    navText: [
                        '<span class="owl-prev-icon"><i class="fa fa-chevron-left"></i></span>',
                        '<span class="owl-next-icon"><i class="fa fa-chevron-right"></i></span>'
                    ],
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 1
                        },
                        1000: {
                            items: 1
                        }
                    }
                });
            } else {
                $carousel.trigger('refresh.owl.carousel');
            }
        });

        // Cosmic Time Lines modal
        $('#cosmic_popup').on('shown.bs.modal', function() {
            var $carousel = $(this).find('.owl-carousel');

            if (!$carousel.hasClass('owl-loaded')) {
                $carousel.owlCarousel({
                    loop: false,
                    margin: 10,
                    nav: true,
                    dots: false,
                    navText: [
                        '<span class="owl-prev-icon"><i class="fa fa-chevron-left"></i></span>',
                        '<span class="owl-next-icon"><i class="fa fa-chevron-right"></i></span>'
                    ],
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 1
                        },
                        1000: {
                            items: 1
                        }
                    }
                });
            } else {
                $carousel.trigger('refresh.owl.carousel');
            }
        });
    });
</script>